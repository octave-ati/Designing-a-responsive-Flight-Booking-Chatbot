#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os

""" Bot Configuration """
pred_key = "4a506641e86b4e979ee2dd02bc08c9a7"
pred_endpoint = 'https://westeurope.api.cognitive.microsoft.com/'
app_id = "abb9267a-7180-4658-93ac-7d0c5e4389c3"
insights_connection_string = "InstrumentationKey=811dc036-4b6a-4575-ab58-6892d2d67992;IngestionEndpoint=https://westeurope-4.in.applicationinsights.azure.com/;LiveEndpoint=https://westeurope.livediagnostics.monitor.azure.com/"


class DefaultConfig:
    """ Bot Configuration """

    PORT = 3978
    APP_ID = os.environ.get("MicrosoftAppId", "")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "")
